// 8. Faça um programa que leia um número de DDI e indique o nome do país correspondente ao DDI. Por exemplo: Digite 1 e o nome do país será "Estados Unidos"; Digitando 49 o nome do país será "Alemanha"; O número 55 mostrará o "Brasil". Caso o usuário digite um número não cadastrado, mostre a mensagem "DDI não existe".

//DDI Disponiveis: Estados Unidos (1), Brasil (55), Alemanha(49).

var ddi = prompt(`Digite o DDI`);

switch (ddi) {
    case "1":
        console.log(`O DDI é dos Estados Unidos.`);
        break;
    case "49":
        console.log(`O DDI é da Alemanha.`);
        break;
    case "55":
        console.log(`O DDI é do Brasil.`);
        break;
    default:
        console.log(`Você não escreveu um DDI valido.`);
}