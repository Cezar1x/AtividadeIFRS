// 9. Faça um algoritmo que leia um número e informe se o número é divisível por 10, por 5, por 2 ou se não é divisível por nenhum destes valores.

var numero = parseInt(prompt("Digite um número:"));

if (numero % 10 === 0 && numero % 5 === 0 && numero % 2 === 0 ) {
  console.log(`${numero} é divisível por 10, 5 e 2.`);
} else {
  console.log(`${numero} não é divisível por 10, 5 e 2.`);
}