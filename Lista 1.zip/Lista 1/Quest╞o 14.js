// 14. Lê um valor de hora e informa quantos minutos se passaram desde o início do dia.

var hora = parseFloat(prompt(`Digite a hora:`));

console.log(`Já se passaram ${(hora*60)} minutos.`);