// 11. Calcule e mostre a área de um triângulo (área é igual a (base x altura) : 2)

var base = parseFloat(prompt(`Digite a base:`));
var altura = parseFloat(prompt(`Digite a altura:`));

console.log(`A área é ${((base*altura)/2)}.`);