// 5. Lê um número e mostra a terça parte deste número.

var num1 = parseFloat(prompt(`Digite o valor:`));

console.log(`A terceira parte do número é ${(num1)/3}.`);