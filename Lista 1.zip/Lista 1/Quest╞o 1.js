// 1. Mostrar na tela o produto entre dois números fornecidos pelo usuário.

var num1 = parseFloat(prompt(`Digite o valor:`));
var num2 = parseFloat(prompt(`Digite o valor:`));

console.log(`O produto é de ${num1} e ${num2} é ${num1*num2}.`);