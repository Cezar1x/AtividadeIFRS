// 13. Leia o numerador e o denominador de uma fração e transforme-o em um número decimal.

var numerador = parseFloat(prompt(`Digite o numerador:`));
var denominador = parseFloat(prompt(`Digite o denominador:`));

console.log(`O número seria ${numerador/denominador}.`);