// 7. Leia 4 números e mostre a média ponderada, sabendo-se que os pesos são respectivamente: 1, 2, 3 e 4.

var num1 = parseFloat(prompt(`Digite o valor:`));
var num2 = parseFloat(prompt(`Digite o valor:`));
var num3 = parseFloat(prompt(`Digite o valor:`));
var num4 = parseFloat(prompt(`Digite o valor:`));

console.log(`A média ponderada é ${(num1+num2+num3+num4)/10}.`);