// 3. Lê um número e mostra seu sucessor e seu antecessor na tela.

var num1 = parseFloat(prompt(`Digite o valor:`));

console.log(`O número digitado foi ${num1}, seu antecessor é ${num1-1} e seu sucessor é ${num1+1}.`);