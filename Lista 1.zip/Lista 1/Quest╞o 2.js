// 2. Mostrar a média aritmética entre 3 números fornecidos pelo usuário.

var num1 = parseFloat(prompt(`Digite o valor:`));
var num2 = parseFloat(prompt(`Digite o valor:`));
var num3 = parseFloat(prompt(`Digite o valor:`));

console.log(`A média aritmética entre ${num1}, ${num2} e ${num3} é ${(num1+num2+num3)/3}.`)