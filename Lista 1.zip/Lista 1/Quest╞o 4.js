// 4. Lê dois números e mostra a soma. Antes do resultado, deverá aparecer a mensagem: SOMA.

var num1 = parseFloat(prompt(`Digite o valor:`));
var num2 = parseFloat(prompt(`Digite o valor:`));

console.log(`A "SOMA" entre esses dois números é ${(num1+num2)}.`);