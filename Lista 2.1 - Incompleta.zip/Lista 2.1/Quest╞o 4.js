// Questão 4. Faça um algoritmo que leia um número e mostra se o número é maior que 20. 

var numero = parseFloat(prompt(`Digite o número:`));

if (numero > 20) {
    console.log(`O número é maior.`);
} else {
    console.log(`O número é menor.`);
}