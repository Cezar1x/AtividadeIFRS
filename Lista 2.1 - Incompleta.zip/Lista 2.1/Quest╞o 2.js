// Questão 2. Faça um algoritmo que leia um número e mostrar se ele é positivo ou negativo. 

var numero = parseFloat(prompt(`Digite o número:`));

if (numero > 0) {
    console.log(`O número é positivo.`);
} else {
    console.log(`O número é negativo.`);
}